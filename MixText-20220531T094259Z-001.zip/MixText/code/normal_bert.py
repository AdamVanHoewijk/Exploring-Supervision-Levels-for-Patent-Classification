import torch
import torch.nn as nn
#from pytorch_transformers import *
import transformers
from transformers.models.bert.modeling_bert import BertEmbeddings, BertPooler, BertLayer, BertPreTrainedModel, BertPreTrainedModel, BertModel

class ClassificationBert(nn.Module):
    def __init__(self, num_labels=2):
        super(ClassificationBert, self).__init__()
        # Load pre-trained bert model
        self.bert = BertPreTrainedModel.from_pretrained('anferico/bert-for-patents')
        self.linear = nn.Sequential(nn.Linear(1024, 128),
                                    nn.Tanh(),
                                    nn.Linear(128, num_labels))

    def forward(self, x, length=256):
        # Encode input text
        print(x)
        all_hidden, pooler = self.bert(x)
        print('True')
        print('print', all_hidden)
        pooled_output = torch.mean(all_hidden, 1)
        # Use linear layer to do the predictions
        predict = self.linear(pooled_output)

        return predict